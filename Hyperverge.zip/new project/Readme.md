##Building a Full Stack Online Blood Bank App that allows volunteers to Donate blood with Spring boot,React,Mysql


### Tutorials


## Steps to Setup the Sring Boot(polling-app-server)

1.In the terminal,


cd polling-app-server

2. **Create MySQL database**

	```bash
	create database polling_app

3.You can run the spring boot app by typing the following command -

	```bash
	mvn spring-boot:run


## Steps to Setup the React Front end app (polling-app-client)

In the terminal,


cd polling-app-client


Then type the following command to install the dependencies and start the application -


npm install && npm start


The front-end server will start on port `3000`.
